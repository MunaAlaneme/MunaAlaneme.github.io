local data = {}

local ae_compDurations = {0, 1}
data.ae_compDurations = ae_compDurations

local ae_effectType = 'effect'
data.ae_effectType = ae_effectType

local ae_transitionInputIndex = {
}
data.ae_transitionInputIndex = ae_transitionInputIndex
local value1 = 20;
local value2 = 2;
local value3 = 0;
local value4 = 1;
local value5 = false;
local value6 = 0;
local value7 = 0;
local value8 = 0;
local value9 = 2;
local value10 = 2;
local value11 = 15;
local value12 = 1;
local value13 = 0;
local value14 = 0.5;
local value15 = 0;
local value16 = 15;
local value17 = 1;
local value18 = 0;
local value19 = 0.5;
local value20 = 0;
local value21 = 0;
local value22 = 10;
local value23 = 0;
local value24 = 0.5;
local value25 = 0;
local value26 = 0.1;
local value27 = 1;
local value28 = 0;
local value29 = 0.5;
local value30 = 0;
local value31 = 1;
local value32 = 1;
local value33 = 1;
local value34 = 0;
local value35 = 0;
local value36 = 0;
local value37 = 0;
local value38 = 2;

data.ae_durations = {
    ['LumiCCLens_76-effect0'] = {
        ['nodeDuration'] = {{0, 3}, },
        ['texDuration'] = {
            ['InputTex'] = {{0, 3}, },
        },
    },
    ['LumiSShake_76-effect1'] = {
        ['nodeDuration'] = {{0, 3}, },
        ['texDuration'] = {
            ['InputTex'] = {{0, 3}, },
        },
    },
    ['LumiLayer_76-blend'] = {
        ['nodeDuration'] = {{0, 3}, },
        ['texDuration'] = {
            ['InputTex'] = {{0, 3}, },
            ['baseTex'] = {{0, 3}, },
        },
    },
    ['LumiLayer_82-matte-blend'] = {
        ['nodeDuration'] = {{0, 3}, },
        ['texDuration'] = {
            ['InputTex'] = {{0, 3}, },
            ['baseTex'] = {{0, 3}, },
            ['maskTex'] = {{0, 3}, },
        },
    },
}
local isEditor = (Amaz.Macros and Amaz.Macros.EditorSDK) and true or false
local exports = exports or {}
local LumiManager = LumiManager or {}
LumiManager.__index = LumiManager
---@class LumiManager : ScriptComponent
---@field debugTime number [UI(Range={0, 6}, Drag)]
---@field autoPlay boolean
---@field lumiEffectRoot Transform
---@field start_render_layer int
---@field start_render_order int

local AE_EFFECT_TAG = 'AE_EFFECT_TAG LumiTag'

local EffectType = {
    Effect = 'effect',
    Transition = 'transition',
    VideoAnimation = 'videoAnimation',
    EffectXT = 'xtEffect',
    FilterXT = 'xtFilter',
}

local AnimationMode = {
    Once = 0,
    Loop = 1,
    StretchOnce = 2,
    StretchLoop = 3,
}

local function clamp(val, min, max)
    return math.min(math.max(val, min), max)
end

local function remap(value, srcMin, srcMax, dstMin, dstMax)
    return dstMin + (value - srcMin) * (dstMax - dstMin) / (srcMax - srcMin)
end

local function handleAllEntityBySingleParent(_trans, func, ...)
    if _trans.children:size() > 0 then
        for i = 1, _trans.children:size() do
            local child = _trans.children:get(i - 1)
            handleAllEntityBySingleParent(child, func, ...)
        end
    end
    func(_trans, ...)
end

local function intervalIntersection(intervals1, intervals2)
    local result = {}
    local i = 1
    local j = 1

    while i <= #intervals1 and j <= #intervals2 do
        local start1 = intervals1[i][1]
        local end1 = intervals1[i][2]
        local start2 = intervals2[j][1]
        local end2 = intervals2[j][2]

        local start = math.max(start1, start2)
        local end_ = math.min(end1, end2)

        if start <= end_ then
            table.insert(result, {start, end_})
        end
        if end1 < end2 then
            i = i + 1
        else
            j = j + 1
        end
    end
    return result
end

function LumiManager.new(construct, ...)
    local self = setmetatable({}, LumiManager)

    self.lumiEffectRoot = nil
    self.start_render_layer = 1
    self.start_render_order = 1

    self.InputTex = nil
    self.OutputTex = nil
    self.PingPongTex = nil

    self.startTime = 0.0
    self.endTime = 6.0
    self.curTime = 0.0

    self.speed = 1.0
    self.animationMode = AnimationMode.Once
    self.autoPlay = true
    self.debugTime = 0.0

    -- for XT
    self.cameraStartTime = 0
    self.lastCycle = -1

    return self
end

function LumiManager:getKeyframeAeTime(aeTime)
    if self.isReverseKeyframes ~= true then
        return aeTime
    end
    return self.compDurations[1] + self.compDurations[2] - aeTime
end

function LumiManager:onDestroy(comp)
    if self.lumiEffectRoot and self.lumi_obj_extension then
        self.lumi_obj_extension.deregister(self.lumiEffectRoot.entity)
    end
    self.lumi_obj = nil
    self.LumiParamsSetter = nil
end

function LumiManager:getCameraCount()
    if self.lumiEffectRoot == nil then
        Amaz.LOGE(AE_EFFECT_TAG, 'Lumi Effect Root is nil, please check')
        return 0
    end

    self.lumi_obj = nil
    self:ReRender()

    local cam_count = 0
    if self.lumi_obj then
        cam_count = self.lumi_obj:getCameraCount()
        Amaz.LOGI(AE_EFFECT_TAG, self.lumi_obj.entity.name .. " camera_count: " .. tostring(cam_count))
    end
    return cam_count
end

function LumiManager:ReRender()
    if self.lumiEffectRoot == nil then
        Amaz.LOGE(AE_EFFECT_TAG, 'Lumi Effect Root is nil, please check')
        return
    end

    -- re register
    self.lumi_obj = nil
    self:registerLumiObj(self.lumiEffectRoot, 1)

    if self.lumi_obj == nil then
        Amaz.LOGE(AE_EFFECT_TAG, 'No lumi_obj register')
        return
    end

    -- change layer & order
    self:updateCameraLayerAndOrder()

    -- change rt pingpong
    self:updateRtPingpong()
end

function LumiManager:registerLumiObj(_trans, _idx)
    if _trans == nil then return end
    local script_comp = _trans.entity:getComponent("ScriptComponent")
    if script_comp then
        local lua_obj = Amaz.ScriptUtils.getLuaObj(script_comp:getScript())
        if lua_obj then
            self.lumi_obj_extension.deregister(_trans.entity)
            self.lumi_obj = self.lumi_obj_extension.register(_trans.entity)
        end
    end
end

local function _setLayer(_cam, _layer)
    local str = "1"
    for i = 1, _layer do
        str = str .. "0"
    end
    local dynamic_bitset = Amaz.DynamicBitset.new(str)

    _cam.layerVisibleMask = dynamic_bitset
end

function LumiManager:updateCameraLayerAndOrder()
    if self.lumi_obj then
        local cur_start_layer, cur_start_order = self.lumi_obj:updateCameraLayerAndOrder(self.start_render_layer, self.start_render_order)

        if self.effectType == EffectType.VideoAnimation then
            cur_start_layer = cur_start_layer + 10
            cur_start_order = cur_start_order + 10

            for i = 1, #self.videoAnimationCameraAndRenderer do
                local cameraAndRenderer = self.videoAnimationCameraAndRenderer[i]
                local camera = cameraAndRenderer.camera
                local renderer = cameraAndRenderer.renderer
                camera.renderOrder = cur_start_order
                _setLayer(camera, cur_start_layer)
                renderer.entity.layer = cur_start_layer
                cur_start_order = cur_start_order + 1
                cur_start_layer = cur_start_layer + 1
            end
        end
    end
end

function LumiManager:updateRtPingpong()
    if self.lumi_obj then
        self.lumi_obj:updateRt(self.InputTex, self.OutputTex, self.PingPongTex)
    end
end

function LumiManager:updateOutputRtSize()
    if self.lumi_obj then
        self.lumi_obj:updateOutputRtSize(self.width, self.height)
    end
end

function LumiManager:initVideoAnimationLua(comp)
    local modelEntity = comp.entity:searchEntity("model")
    if modelEntity then
        local scriptComp = modelEntity:getComponent("ScriptComponent")
        if scriptComp then
            self.videoAnimationLua = Amaz.ScriptUtils.getLuaObj(scriptComp:getScript())
        end
    end
end

function LumiManager:onUpdate(comp, deltaTime)
    data.ae_attribute = {
        ['LumiCCLens_76-effect0'] = {
            ['convergence'] = 0,
            ['radius'] = 300,
            ['center'] = Amaz.Vector2f(0.5, 0.5),
            ['AEDesignSize'] = Amaz.Vector2f(512, 512),
        },
        ['LumiSShake_76-effect1'] = {
            ['ampRatio'] = value1,
            ['frqRatio'] = value2,
            ['phase0'] = value3,
            ['scale0'] = value4,
            ['blurEnabled'] = value5,
            ['blurIntensity'] = value6,
            ['blurQuality'] = value7,
            ['seed'] = value8,
            ['xFill'] = value9,
            ['yFill'] = value10,
            ['xAmpR'] = value11,
            ['xFrqR'] = value12,
            ['xAmp'] = value13,
            ['xFrq'] = value14,
            ['xPhase'] = value15,
            ['yAmpR'] = value16,
            ['yFrqR'] = value17,
            ['yAmp'] = value18,
            ['yFrq'] = value19,
            ['yPhase'] = value20,
            ['zAmpR'] = value21,
            ['zFrqR'] = value22,
            ['zAmp'] = value23,
            ['zFrq'] = value24,
            ['zPhase'] = value25,
            ['wAmpR'] = value26,
            ['wFrqR'] = value27,
            ['wAmp'] = value28,
            ['wFrq'] = value29,
            ['wPhase'] = value30,
            ['rAmpRatio'] = value31,
            ['gAmpRatio'] = value32,
            ['bAmpRatio'] = value33,
            ['rPhase'] = value34,
            ['gPhase'] = value35,
            ['bPhase'] = value36,
            ['rgbRnd'] = value37,
            ['rgbFrq'] = value38,
            ['AEDesignSize'] = Amaz.Vector2f(512, 512),
        },
        ['LumiLayer_76-blend'] = {
            ['hasBlend'] = true,
            ['hasMatte'] = false,
            ['hasTransform'] = false,
            ['layerType'] = 'Adjustment',
            ['blendMode'] = 0,
        },
        ['LumiFaceMask_86-effect0'] = {
            ['faceMode'] = 0,
            ['faceDetectInterval'] = 0,
            ['maskType'] = 0,
            ['reverseTaking'] = false,
            ['AEDesignSize'] = Amaz.Vector2f(512, 512),
        },
        ['LumiGaussianBlur_86-effect1'] = {
            ['blurIntensity'] = 0,
            ['quality'] = 0.5,
            ['spaceDither'] = 0,
            ['horizontalStrength'] = 1,
            ['verticalStrength'] = 1,
            ['blurDirection'] = 0,
            ['borderType'] = 0,
            ['blurAlpha'] = true,
            ['inverseGammaCorrection'] = true,
            ['AEDesignSize'] = Amaz.Vector2f(512, 512),
        },
        ['LumiGaussianBlur_82-effect0'] = {
            ['blurIntensity'] = 0,
            ['quality'] = 0.5,
            ['spaceDither'] = 0,
            ['horizontalStrength'] = 1,
            ['verticalStrength'] = 1,
            ['blurDirection'] = 0,
            ['borderType'] = 0,
            ['blurAlpha'] = true,
            ['inverseGammaCorrection'] = true,
            ['AEDesignSize'] = Amaz.Vector2f(512, 512),
        },
        ['LumiLayer_82-matte-blend'] = {
            ['hasBlend'] = true,
            ['hasMatte'] = true,
            ['hasTransform'] = false,
            ['layerType'] = 'Adjustment',
            ['matteMode'] = 0,
            ['blendMode'] = 0,
        },
    }

    data.ae_sliderInfos = {
        ['effects_adjust_intensity'] = {
            {'LumiSShake_76-effect1', 'ampRatio', 'number', {true, }, 1, 2, 0, 1, {0, }, {0, }, },
        },
    }
    self.entity = comp.entity

    self.lumi_obj_extension = includeRelativePath("LumiObjectExtension")
    self.lumi_obj = nil

    self.keyframes = nil
    self.durations = nil
    self.params = nil
    self.compDurations = {0, 6}
    self.animationInfos = 0
    self.sliderInfos = {}
    self.effectType = "effect"
    self.transitionInputIndex = {}

    self.LumiParamsSetter = includeRelativePath("LumiParamsSetter")
    if data then
        if data.ae_keyframes then
            local ae_tools = includeRelativePath("AETools")
            if ae_tools then
                self.keyframes = ae_tools.new(data.ae_keyframes)
            end
        end
        if data.ae_reverseKeyframes ~= nil then
            self.isReverseKeyframes = data.ae_reverseKeyframes
        end
        if data.ae_durations ~= nil then
            self.durations = data.ae_durations
        end
        self.params = data.ae_attribute
        if data.ae_compDurations ~= nil then
            self.compDurations = data.ae_compDurations
            self.compDurations[2] = self.compDurations[2]
        end
        if data.ae_animationInfos ~= nil then
            self.animationInfos = data.ae_animationInfos
            self.animationMode = self.animationInfos.animationMode
            self.loopStart = self.animationInfos.loopStart
            self.speed = self.animationInfos.speedInfo[1]
        end
        if data.ae_sliderInfos ~= nil then
            self.sliderInfos = data.ae_sliderInfos
        end
        if data.ae_effectType ~= nil then
            self.effectType = data.ae_effectType
        end
        if data.ae_cameraMode ~= nil then
            self.cameraMode = data.ae_cameraMode
        end
        if data.ae_transitionInputIndex ~= nil then
            self.transitionInputIndex = data.ae_transitionInputIndex
        end
    end
    if self.LumiParamsSetter then
        self.lumi_params_setter = self.LumiParamsSetter.new(
            self,
            self.params,
            self.keyframes,
            self.effectType,
            self.sliderInfos
        )
    end
    if self.lumiEffectRoot == nil then
        Amaz.LOGE(AE_EFFECT_TAG, 'Lumi Effect Root is nil, please check')
        return
    end

    if self.lumi_obj == nil then
        self:registerLumiObj(self.lumiEffectRoot, 1)
        self:updateCameraLayerAndOrder()
    end

    if self.durations and not self.isSetDuration then
        for entityName, durationMap in pairs(self.durations) do
            local isLumiLayer = string.sub(entityName, 1, string.len('LumiLayer')) == 'LumiLayer'
            if isLumiLayer then
                local texDuration = durationMap['texDuration']
                local srcDuration = texDuration['InputTex']
                local baseDuration = texDuration['baseTex']
                local maskDuration = texDuration['maskTex']
                if srcDuration then
                    self.lumi_obj:setSubEffectAttr(entityName, 'srcDuration', srcDuration)
                end
                if baseDuration then
                    self.lumi_obj:setSubEffectAttr(entityName, 'baseDuration', baseDuration)
                end
                if maskDuration then
                    local matteDuration = intervalIntersection(maskDuration, srcDuration)
                    self.lumi_obj:setSubEffectAttr(entityName, 'matteDuration', matteDuration)
                end
            end
        end
        self.isSetDuration = true
    end

    local w = Amaz.BuiltinObject.getInputTextureWidth()
    local h = Amaz.BuiltinObject.getInputTextureHeight()
    if self.InputTex then
        w = self.InputTex.width
        h = self.InputTex.height
    end
    if self.OutputTex and (self.OutputTex.width ~= w or self.OutputTex.height ~= h) then
        Amaz.LOGE(AE_EFFECT_TAG, 'Invalid rt size, input: ' .. w .. 'x' .. h .. ', output: ' .. self.OutputTex.width .. 'x' .. self.OutputTex.height)
    end
    if self.width == nil or self.width ~= w or self.height == nil or self.height ~= h then
        self.width = w
        self.height = h
        self:updateOutputRtSize()
    end

    self.curTime = self.curTime + deltaTime
    if isEditor then
        self.curTime = self.curTime % self.endTime
    end
    local curTime = (self.curTime - self.startTime) * self.speed + self.startTime
    local startTime = self.startTime
    local endTime = (self.endTime - self.startTime) * self.speed + self.startTime

    if self.cameraMode then
        if self.animationMode ~= AnimationMode.Loop then
            Amaz.LOGE(AE_EFFECT_TAG, 'Camera mode is not support animationMode: ' .. tostring(self.animationMode))
            return
        end
        curTime = self.curTime - self.cameraStartTime
        endTime = math.huge
    elseif self.effectType == EffectType.EffectXT or self.effectType == EffectType.FilterXT then -- deprecated after 1810 in XT
        startTime = 0
        if self.isVideo then
            endTime = self.videoTime
        else
            endTime = 3
        end
    end

    local aeTime = curTime;
    local aeDuration = math.max(0.001, self.compDurations[2] - self.compDurations[1])
    if endTime < curTime then
        aeTime = math.max(self.compDurations[1], self.compDurations[2] - (self.endTime - self.curTime))
    else
        local lvDuration = math.max(0.001, endTime - startTime)
        if self.animationMode == AnimationMode.Once then
            aeTime = self.compDurations[1] + curTime - startTime
            aeTime = math.min(aeTime, self.compDurations[2])
        elseif self.animationMode == AnimationMode.Loop then
            if self.cameraMode then
                local cycle = math.floor((curTime - startTime) / aeDuration)
                if self.lastCycle ~= cycle then
                    self.lastCycle = cycle
                    comp.entity.scene:sendMessage(4999, 1, 0, '')
                end
            end
            if math.floor((curTime - startTime) / aeDuration) < 1 then
                aeTime = self.compDurations[1] + (curTime - startTime) % aeDuration
            else
                local curLoopStart = (self.loopStart - self.compDurations[1]) * self.speed + self.compDurations[1]
                aeTime = self.loopStart + (curTime - startTime - curLoopStart) % (aeDuration - self.loopStart)
            end
        elseif self.animationMode == AnimationMode.StretchOnce then
            aeTime = remap(curTime, startTime, self.endTime, self.compDurations[1], self.compDurations[2])
            aeTime = clamp(aeTime, self.compDurations[1], self.compDurations[2])
        elseif self.animationMode == AnimationMode.StretchLoop then
            local newCurTime = startTime + (curTime - startTime) * self.speed % lvDuration
            aeTime = remap(newCurTime, startTime, endTime, self.compDurations[1], self.compDurations[2])

            if math.floor((curTime - startTime) * self.speed / lvDuration) >= 1 then
                aeTime = self.compDurations[1] + (aeTime - self.compDurations[1]) % (self.compDurations[2] - self.loopStart) + self.loopStart
            end
        end
    end

    if self.effectType == EffectType.Transition then
        local input1 = Amaz.BuiltinObject.getUserTexture("#TransitionInput0")
        local input2 = Amaz.BuiltinObject.getUserTexture("#TransitionInput1")
        if input1 and input2 then
            for index, transitionInputInfo in ipairs(self.transitionInputIndex) do
                local entityName = transitionInputInfo[1]
                local texName = transitionInputInfo[2]
                local inputIndex = transitionInputInfo[3]
                if inputIndex == 0 then
                    self.lumi_obj:setSubEffectAttr(entityName, texName, input1)
                    self.lumi_obj:setSubEffectAttr(entityName, 'algoSlot', 0)
                else
                    self.lumi_obj:setSubEffectAttr(entityName, texName, input2)
                    self.lumi_obj:setSubEffectAttr(entityName, 'algoSlot', 1)
                end
            end
            aeTime = Amaz.Input.frameTimestamp * (self.compDurations[2] - self.compDurations[1]) + self.compDurations[1]
        end
    elseif self.effectType == EffectType.VideoAnimation then
        if self.videoAnimationLua == nil then
            self:initVideoAnimationLua(comp)
        end
        if self.videoAnimationLua ~= nil then
            aeTime = remap(self.videoAnimationLua.curTime, 0, self.videoAnimationLua.duration, self.compDurations[1], self.compDurations[2])
        end
    end

    if isEditor then
        if self.autoPlay then
            self.debugTime = curTime % (self.compDurations[2] - self.compDurations[1]) + self.compDurations[1]
            aeTime = self.debugTime
        else
            aeTime = self.debugTime
        end
    elseif self.effectType == EffectType.VideoAnimation or self.effectType == EffectType.Transition then
        self.curTime = aeTime
    end

    if self.lumi_obj then
        self.lumi_obj:setEffectAttrRecursively("startTime", self.startTime)
        self.lumi_obj:setEffectAttrRecursively("endTime", self.endTime)
        self.lumi_obj:setEffectAttrRecursively("curTime", self.curTime)
        self.lumi_obj:setEffectAttrRecursively("aeTime", aeTime)
        self.lumi_obj:setEffectAttrRecursively("aeDuration", aeDuration)
    end

    if self.lumi_params_setter and self.lumi_params_setter.initParams then
        self.lumi_params_setter:initParams(self.lumi_obj)
    end
    if self.lumi_params_setter and self.lumi_params_setter.updateKeyFrameData then
        self.lumi_params_setter:updateKeyFrameData(self.lumi_obj, aeTime)
    end
    if self.lumi_params_setter and self.lumi_params_setter.updateSlider then
        self.lumi_params_setter:updateSlider(self.lumi_obj, aeTime)
    end

    if self.lumi_obj and self.durations ~= nil then
        aeTime = math.min(math.max(aeTime, self.compDurations[1]), self.compDurations[2])
        for entityName, durationMap in pairs(self.durations) do
            local nodeDuration = durationMap['nodeDuration']
            local visible = false
            for j = 1, #nodeDuration do
                if nodeDuration[j][1] <= aeTime and aeTime < nodeDuration[j][2] then
                    visible = true
                    break
                end
            end
            self.lumi_obj:setVisible(entityName, visible)
        end
    end
    if self.lumi_obj and self.lumi_obj.updateMaterials then
        self.lumi_obj:updateMaterials(deltaTime)
    end
end

function LumiManager:onEvent(comp, event)
    if self.lumiEffectRoot == nil then
        Amaz.LOGE(AE_EFFECT_TAG, 'Lumi Effect Root is nil, please check')
        return
    end

    if self.lumi_obj == nil then
        self:registerLumiObj(self.lumiEffectRoot, 1)
        self:updateCameraLayerAndOrder()
    end

    if self.lumi_obj == nil then
        Amaz.LOGE(AE_EFFECT_TAG, 'Failed to find lumi_obj')
        return
    end

    if event.args:get(0) == 'effects_adjust_blur' then
        value1 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter' then
        value2 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity' then
        value3 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur2' then
        value4 = event.args:get(1)*10.0
    end
    if event.args:get(0) == 'effects_adjust_filter2' then
        value5 = false
        if event.args:get(1) >= 0.5 then
            value5 = true
        end
    end
    if event.args:get(0) == 'effects_adjust_intensity2' then
        value6 = event.args:get(1)
    end
    if event.args:get(0) == 'effects_adjust_blur3' then
        value7 = event.args:get(1)*5.0
    end
    if event.args:get(0) == 'effects_adjust_filter3' then
        value8 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity3' then
        value9 = math.floor(event.args:get(1)*2.0 + 0.5)
    end
    if event.args:get(0) == 'effects_adjust_blur4' then
        value10 = math.floor(event.args:get(1)*2.0 + 0.5)
    end
    if event.args:get(0) == 'effects_adjust_filter4' then
        value11 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity4' then
        value12 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur5' then
        value13 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter5' then
        value14 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity5' then
        value15 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur6' then
        value16 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter6' then
        value17 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity6' then
        value18 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur7' then
        value19 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter7' then
        value20 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity7' then
        value21 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur8' then
        value22 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter8' then
        value23 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity8' then
        value24 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur9' then
        value25 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter9' then
        value26 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity9' then
        value27 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur10' then
        value28 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter10' then
        value29 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity10' then
        value30 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur11' then
        value31 = event.args:get(1)*10.0
    end
    if event.args:get(0) == 'effects_adjust_filter11' then
        value32 = event.args:get(1)*10.0
    end
    if event.args:get(0) == 'effects_adjust_intensity11' then
        value33 = event.args:get(1)*10.0
    end
    if event.args:get(0) == 'effects_adjust_blur12' then
        value34 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter12' then
        value35 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_intensity12' then
        value36 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_blur13' then
        value37 = event.args:get(1)*100.0
    end
    if event.args:get(0) == 'effects_adjust_filter13' then
        value38 = event.args:get(1)*100.0
    end
    if self.lumi_params_setter and self.lumi_params_setter.onEvent then
        self.lumi_params_setter:onEvent(self.lumi_obj, event)
    end
end

exports.LumiManager = LumiManager
return exports
