
graphBuild = graphBuild or {} ---@type graphBuild
graphBuild.__typename = "graphBuild"
graphBuild.__supername = "ScriptComponent"
graphBuild.__scriptname = ""
graphBuild.__scriptpath = ""

